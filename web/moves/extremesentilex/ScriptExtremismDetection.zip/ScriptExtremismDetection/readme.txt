*****************************
*****************************
*****					*****
*****		README		*****
*****					*****
*****************************
*****************************




INTRODUCTION
------------

You can find in this the script for the detection of extreme
sentiments on text ScriptExtremismDetection.py file.
This file is just a sample. You can use it and make changes 
on the code to apply to your datasets or text.
In this barebone code (totally funcional) you can choose to
use a dataset of many sentences or test for only one sentece.




INSTRUCTIONS
------------

You need to give to the script the path for an extreme 
sentiment lexicon and to the dataset you want to classify
or you can choose only a sentece and se the results.
Also as the Script is open, you can change it in order to
work with the datasets you choose it is easy to change.




CONTACTS
--------

Any questions you have you may contact the developers
of this script:

Miguel Albardeiro: 	miguelsalbardeiro(at)gmail.com
Sebastião Pais: 	sebatiao(at)di.ubi.pt