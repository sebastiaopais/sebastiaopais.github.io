*****************************
*****************************
*****					*****
*****		README		*****
*****					*****
*****************************
*****************************

LEXICON FILE
------------

	ExtremeSentiLex.txt

HEADER
------

	term	score

MEANING
-------

	term  - word or set of words
	score - value from 0 to 1 for the terms polarity